package com.pengyi.screenpicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;

import java.util.List;

public class TextBoxesView extends View {
    public interface SelectionListener { void onSelectionChanged(); }

    private final List<TextItem> items;
    private final boolean selectable;
    private final Paint normal = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selected = new Paint(Paint.ANTI_ALIAS_FLAG);
    private SelectionListener listener;

    public TextBoxesView(Context context, List<TextItem> items, boolean selectable) {
        super(context);
        this.items = items;
        this.selectable = selectable;
        normal.setStyle(Paint.Style.FILL);
        normal.setColor(Color.argb(55, 91, 108, 255));
        selected.setStyle(Paint.Style.FILL);
        selected.setColor(Color.argb(125, 91, 108, 255));
    }

    public void setSelectionListener(SelectionListener listener) { this.listener = listener; }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (TextItem item : items) {
            Rect r = item.bounds;
            canvas.drawRoundRect(r.left, r.top, r.right, r.bottom, 6, 6, item.selected ? selected : normal);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!selectable) return true;
        if (event.getAction() == MotionEvent.ACTION_UP) {
            float x = event.getX(), y = event.getY();
            for (int i = items.size() - 1; i >= 0; i--) {
                TextItem item = items.get(i);
                if (item.bounds.contains((int) x, (int) y)) {
                    item.selected = !item.selected;
                    invalidate();
                    if (listener != null) listener.onSelectionChanged();
                    return true;
                }
            }
        }
        return true;
    }
}
