package com.pengyi.screenpicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityService.ScreenshotResult;
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ScreenAccessibilityService extends AccessibilityService {
    private static ScreenAccessibilityService instance;

    private WindowManager wm;
    private Handler handler;
    private AppDb db;
    private OcrEngine ocr;
    private SharedPreferences prefs;

    private TextView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private LinearLayout menu;
    private WindowManager.LayoutParams menuLp;
    private FrameLayout resultOverlay;
    private FrameLayout rectOverlay;
    private String currentPackage = "";
    private String operationPackage = "";
    private String operationAppName = "";
    private boolean docked = false;
    private boolean bubbleAdded = false;
    private float downRawX, downRawY;
    private int downX, downY;
    private static final int BUBBLE_DP = 56;

    private final Runnable idleRunnable = () -> {
        removeMenu();
        dockBubble();
    };

    public static ScreenAccessibilityService getInstance() { return instance; }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        handler = new Handler(Looper.getMainLooper());
        db = new AppDb(this);
        ocr = new OcrEngine();
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        db.log("INFO", "无障碍取词服务已连接");
        refreshFloatingUi();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if (!pkg.equals(getPackageName()) && !pkg.equals("com.android.systemui") && !pkg.equals("com.android.settings")) {
            currentPackage = pkg;
        }
    }

    @Override public void onInterrupt() { if (db != null) db.log("WARN", "无障碍服务被中断"); }

    @Override
    public void onDestroy() {
        removeAllOverlays();
        if (ocr != null) ocr.close();
        if (db != null) db.log("INFO", "无障碍取词服务已停止");
        instance = null;
        super.onDestroy();
    }

    public void refreshFloatingUi() {
        if (wm == null) return;
        if (!Settings.canDrawOverlays(this)) {
            removeAllOverlays();
            return;
        }
        if (!bubbleAdded) showBubble();
        else {
            bubble.setAlpha(1f);
            makeBubbleVisible();
            scheduleIdle();
        }
    }

    private void showBubble() {
        if (!Settings.canDrawOverlays(this) || bubbleAdded) return;
        bubble = new TextView(this);
        bubble.setText("取");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(18);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackgroundResource(com.pengyi.screenpicker.R.drawable.bubble_bg);
        bubble.setElevation(dp(10));
        bubble.setOnTouchListener(this::handleBubbleTouch);

        int size = dp(BUBBLE_DP);
        bubbleLp = new WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = screenWidth() - size - dp(6);
        bubbleLp.y = Math.max(dp(90), screenHeight()/3);
        try {
            wm.addView(bubble, bubbleLp);
            bubbleAdded = true;
            db.log("INFO", "悬浮球已显示");
            scheduleIdle();
        } catch (Exception e) {
            db.log("ERROR", "显示悬浮球失败: " + e.getMessage());
        }
    }

    private boolean handleBubbleTouch(View v, MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                cancelIdle();
                makeBubbleVisible();
                downRawX = e.getRawX(); downRawY = e.getRawY();
                downX = bubbleLp.x; downY = bubbleLp.y;
                return true;
            case MotionEvent.ACTION_MOVE:
                int nx = downX + Math.round(e.getRawX() - downRawX);
                int ny = downY + Math.round(e.getRawY() - downRawY);
                bubbleLp.x = Math.max(-dp(10), Math.min(screenWidth()-dp(BUBBLE_DP)+dp(10), nx));
                bubbleLp.y = Math.max(dp(16), Math.min(screenHeight()-dp(BUBBLE_DP)-dp(28), ny));
                safeUpdate(bubble, bubbleLp);
                return true;
            case MotionEvent.ACTION_UP:
                float dx = Math.abs(e.getRawX()-downRawX), dy = Math.abs(e.getRawY()-downRawY);
                if (dx < dp(8) && dy < dp(8)) toggleMenu();
                else { snapBubble(false); scheduleIdle(); }
                return true;
        }
        return false;
    }

    private void toggleMenu() {
        makeBubbleVisible();
        if (menu != null) { removeMenu(); scheduleIdle(); return; }
        menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setPadding(dp(8), dp(8), dp(8), dp(8));
        menu.setBackgroundResource(com.pengyi.screenpicker.R.drawable.menu_bg);
        menu.setElevation(dp(12));
        menu.addView(menuButton("全屏取词", () -> startMode("FULL")));
        menu.addView(menuButton("自定义取词", () -> startMode("CUSTOM")));
        menu.addView(menuButton("矩形框取词", () -> startMode("RECT")));

        menuLp = new WindowManager.LayoutParams(dp(150), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        menuLp.gravity = Gravity.TOP | Gravity.START;
        boolean rightSide = bubbleLp.x > screenWidth()/2;
        menuLp.x = rightSide ? Math.max(dp(8), bubbleLp.x - dp(156)) : bubbleLp.x + dp(BUBBLE_DP) + dp(8);
        menuLp.y = Math.max(dp(20), Math.min(screenHeight()-dp(210), bubbleLp.y-dp(30)));
        try { wm.addView(menu, menuLp); db.log("INFO", "悬浮菜单已展开"); }
        catch (Exception e) { db.log("ERROR", "显示悬浮菜单失败: "+e.getMessage()); menu = null; }
        scheduleIdle();
    }

    private View menuButton(String name, Runnable run) {
        TextView b = new TextView(this);
        b.setText(name); b.setTextColor(Color.rgb(21,24,39)); b.setTextSize(15); b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(dp(14),0,dp(10),0);
        b.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        lp.setMargins(0,dp(1),0,dp(1)); b.setLayoutParams(lp);
        b.setOnClickListener(v -> run.run());
        return b;
    }

    private void startMode(String mode) {
        cancelIdle(); removeMenu(); captureSource(); hideBubble();
        db.log("INFO", "开始"+modeName(mode)+"，来源: "+operationAppName+" ("+operationPackage+")");
        if ("RECT".equals(mode)) {
            handler.postDelayed(this::showRectSelector, 120);
            return;
        }
        List<TextItem> direct = collectAccessibleText();
        if (!direct.isEmpty()) {
            String text = OcrEngine.join(direct);
            db.log("INFO", modeName(mode)+"直接读取到 "+direct.size()+" 个文本元素");
            if ("CUSTOM".equals(mode)) showCustomResult(direct, mode);
            else showFixedResult(direct, text, mode);
        } else {
            db.log("INFO", "可访问文本为空，切换 OCR 截图识别");
            handler.postDelayed(() -> screenshotOcr(null, mode), 120);
        }
    }

    private void captureSource() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null && root.getPackageName() != null) currentPackage = root.getPackageName().toString();
        } catch (Exception ignored) { }
        operationPackage = currentPackage == null ? "" : currentPackage;
        operationAppName = resolveAppName(operationPackage);
    }

    private List<TextItem> collectAccessibleText() {
        List<TextItem> out = new ArrayList<>();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return out;
        Set<String> seen = new HashSet<>();
        ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
        q.add(root);
        int guard = 0;
        while (!q.isEmpty() && guard++ < 4000) {
            AccessibilityNodeInfo n = q.removeFirst();
            if (n == null) continue;
            CharSequence raw = n.getText();
            if ((raw == null || raw.length()==0) && n.getContentDescription()!=null) raw = n.getContentDescription();
            if (raw != null) {
                String s = raw.toString().trim();
                Rect r = new Rect(); n.getBoundsInScreen(r);
                if (!s.isEmpty() && r.width()>1 && r.height()>1 && n.isVisibleToUser()) {
                    String key = s+"@"+r.flattenToString();
                    if (seen.add(key)) out.add(new TextItem(s, r));
                }
            }
            for (int i=0;i<n.getChildCount();i++) {
                AccessibilityNodeInfo child = n.getChild(i);
                if (child != null) q.addLast(child);
            }
        }
        return out;
    }

    private void screenshotOcr(Rect filter, String mode) {
        takeScreenshot(getDisplayIdSafe(), getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult screenshot) {
                Bitmap bitmap = null;
                HardwareBuffer hb = null;
                try {
                    hb = screenshot.getHardwareBuffer();
                    Bitmap hw = Bitmap.wrapHardwareBuffer(hb, screenshot.getColorSpace());
                    if (hw != null) bitmap = hw.copy(Bitmap.Config.ARGB_8888, false);
                } catch (Exception e) {
                    db.log("ERROR", "截图转换失败: "+e.getMessage());
                } finally {
                    if (hb != null) try { hb.close(); } catch (Exception ignored) { }
                }
                if (bitmap == null) { failOperation("无法读取截图图像"); return; }
                Bitmap finalBitmap = bitmap;
                long started = System.currentTimeMillis();
                ocr.recognize(finalBitmap, filter, new OcrEngine.Callback() {
                    @Override public void onSuccess(List<TextItem> items, String fullText) {
                        finalBitmap.recycle();
                        db.log("INFO", "OCR 完成，识别 "+items.size()+" 项，耗时 "+(System.currentTimeMillis()-started)+"ms");
                        if (items.isEmpty() && (fullText==null || fullText.trim().isEmpty())) { failOperation("没有识别到文字"); return; }
                        if ("CUSTOM".equals(mode)) showCustomResult(items, mode);
                        else showFixedResult(items, fullText, mode);
                    }
                    @Override public void onError(Exception error) {
                        finalBitmap.recycle();
                        db.log("ERROR", "OCR 失败: "+error.getMessage());
                        failOperation("OCR 识别失败");
                    }
                });
            }
            @Override public void onFailure(int errorCode) {
                db.log("ERROR", "系统截图失败，错误码: "+errorCode);
                if (errorCode == ERROR_TAKE_SCREENSHOT_SECURE_WINDOW) failOperation("当前窗口禁止屏幕截图");
                else failOperation("系统截图失败，错误码 "+errorCode);
            }
        });
    }

    private int getDisplayIdSafe() {
        try { return getDisplay().getDisplayId(); } catch (Exception e) { return 0; }
    }

    private void showRectSelector() {
        if (!Settings.canDrawOverlays(this)) { failOperation("悬浮窗权限未开启"); return; }
        rectOverlay = new FrameLayout(this);
        RectSelectionView selector = new RectSelectionView(this, new RectSelectionView.Listener() {
            @Override public void onSelected(Rect rect) {
                db.log("INFO", "矩形区域: "+rect.flattenToString());
                removeRectOverlay();
                handler.postDelayed(() -> screenshotOcr(rect, "RECT"), 120);
            }
            @Override public void onCancelled() { finishOperation(); }
        });
        rectOverlay.addView(selector, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView tip = new TextView(this); tip.setText("拖动框选需要识别的区域"); tip.setTextColor(Color.WHITE); tip.setTextSize(15); tip.setGravity(Gravity.CENTER);
        tip.setBackgroundColor(Color.argb(160, 20,22,32));
        FrameLayout.LayoutParams tipLp = new FrameLayout.LayoutParams(dp(230), dp(46), Gravity.TOP|Gravity.CENTER_HORIZONTAL); tipLp.topMargin=dp(52); rectOverlay.addView(tip,tipLp);
        Button cancel = new Button(this); cancel.setText("取消"); cancel.setAllCaps(false); cancel.setOnClickListener(v -> finishOperation());
        FrameLayout.LayoutParams cLp = new FrameLayout.LayoutParams(dp(90),dp(48),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); cLp.bottomMargin=dp(36); rectOverlay.addView(cancel,cLp);

        WindowManager.LayoutParams lp = fullOverlayParams();
        try { wm.addView(rectOverlay, lp); } catch(Exception e){ db.log("ERROR","矩形选择层失败: "+e.getMessage()); rectOverlay=null; failOperation("无法显示矩形选择层"); }
    }

    private void showFixedResult(List<TextItem> items, String text, String mode) {
        removeResultOverlay();
        resultOverlay = new FrameLayout(this);
        TextBoxesView boxes = new TextBoxesView(this, items, false);
        resultOverlay.addView(boxes, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        String clean = text == null || text.trim().isEmpty() ? OcrEngine.join(items) : text.trim();
        if (!clean.isEmpty()) db.addHistory(clean, operationPackage, operationAppName, mode);

        LinearLayout bar = resultBar();
        TextView title = barTitle(modeName(mode)+" · "+items.size()+" 项");
        TextView preview = barSub(shorten(clean, 130));
        bar.addView(title); bar.addView(preview);
        LinearLayout actions = actionRow();
        Button copy = resultButton("复制全部"); copy.setOnClickListener(v -> { copyToClipboard(clean); db.log("INFO",modeName(mode)+"结果已复制"); });
        Button finish = resultButton("完成"); finish.setOnClickListener(v -> finishOperation());
        actions.addView(copy,new LinearLayout.LayoutParams(0,dp(46),1)); actions.addView(finish,new LinearLayout.LayoutParams(0,dp(46),1));
        bar.addView(actions);
        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM); barLp.setMargins(dp(12),0,dp(12),dp(22)); resultOverlay.addView(bar,barLp);
        addResultOverlay();
    }

    private void showCustomResult(List<TextItem> items, String mode) {
        removeResultOverlay();
        resultOverlay = new FrameLayout(this);
        TextBoxesView boxes = new TextBoxesView(this, items, true);
        resultOverlay.addView(boxes, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout bar = resultBar();
        TextView title = barTitle("自定义取词 · 点击文字选择");
        TextView count = barSub("已选择 0 项");
        bar.addView(title); bar.addView(count);
        boxes.setSelectionListener(() -> count.setText("已选择 "+selectedItems(items).size()+" 项"));
        LinearLayout actions = actionRow();
        Button copy = resultButton("复制选择"); copy.setOnClickListener(v -> {
            List<TextItem> selected = selectedItems(items);
            if (selected.isEmpty()) { toast("请先点击选择文字"); return; }
            String s = OcrEngine.join(selected);
            copyToClipboard(s); db.addHistory(s, operationPackage, operationAppName, mode); db.log("INFO","自定义取词复制 "+selected.size()+" 项");
        });
        Button all = resultButton("全选"); all.setOnClickListener(v -> { for(TextItem i:items)i.selected=true; boxes.invalidate(); count.setText("已选择 "+items.size()+" 项"); });
        Button finish = resultButton("完成"); finish.setOnClickListener(v -> finishOperation());
        actions.addView(copy,new LinearLayout.LayoutParams(0,dp(46),1)); actions.addView(all,new LinearLayout.LayoutParams(0,dp(46),1)); actions.addView(finish,new LinearLayout.LayoutParams(0,dp(46),1));
        bar.addView(actions);
        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,Gravity.BOTTOM);barLp.setMargins(dp(12),0,dp(12),dp(22));resultOverlay.addView(bar,barLp);
        addResultOverlay();
    }

    private void addResultOverlay() {
        try { wm.addView(resultOverlay, fullOverlayParams()); }
        catch(Exception e){ db.log("ERROR","结果覆盖层失败: "+e.getMessage()); resultOverlay=null; failOperation("无法显示识别结果"); }
    }

    private LinearLayout resultBar() {
        LinearLayout bar = new LinearLayout(this); bar.setOrientation(LinearLayout.VERTICAL); bar.setPadding(dp(14),dp(12),dp(14),dp(12));
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(); g.setColor(Color.argb(245,248,249,255)); g.setCornerRadius(dp(20)); g.setStroke(dp(1),Color.rgb(217,221,241)); bar.setBackground(g); bar.setElevation(dp(12)); return bar;
    }
    private TextView barTitle(String s){ TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.rgb(21,24,39));t.setTextSize(15);t.setTypeface(null,1);return t; }
    private TextView barSub(String s){ TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.rgb(92,97,116));t.setTextSize(12);t.setMaxLines(3);t.setPadding(0,dp(4),0,dp(8));return t; }
    private LinearLayout actionRow(){ LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setPadding(0,dp(4),0,0);return r; }
    private Button resultButton(String s){ Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(Color.WHITE);android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(Color.rgb(91,108,255));g.setCornerRadius(dp(12));b.setBackground(g);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(46),1);p.setMargins(dp(3),0,dp(3),0);b.setLayoutParams(p);return b; }

    private List<TextItem> selectedItems(List<TextItem> items) { List<TextItem> out=new ArrayList<>();for(TextItem i:items)if(i.selected)out.add(i);return out; }

    private void finishOperation() {
        removeResultOverlay(); removeRectOverlay();
        if (!bubbleAdded && Settings.canDrawOverlays(this)) showBubble();
        else showBubbleNow();
        db.log("INFO", "取词操作结束");
        scheduleIdle();
    }

    private void failOperation(String message) {
        toast(message); db.log("WARN", message); finishOperation();
    }

    private void hideBubble() { if(bubbleAdded && bubble!=null) bubble.setVisibility(View.GONE); }
    private void showBubbleNow(){ if(bubbleAdded && bubble!=null){bubble.setVisibility(View.VISIBLE);bubble.setAlpha(1f);makeBubbleVisible();} }

    private void removeMenu(){ if(menu!=null){try{wm.removeView(menu);}catch(Exception ignored){} menu=null;} }
    private void removeResultOverlay(){ if(resultOverlay!=null){try{wm.removeView(resultOverlay);}catch(Exception ignored){} resultOverlay=null;} }
    private void removeRectOverlay(){ if(rectOverlay!=null){try{wm.removeView(rectOverlay);}catch(Exception ignored){} rectOverlay=null;} }
    private void removeAllOverlays(){ cancelIdle();removeMenu();removeResultOverlay();removeRectOverlay();if(bubbleAdded&&bubble!=null){try{wm.removeView(bubble);}catch(Exception ignored){}bubbleAdded=false;bubble=null;} }

    private WindowManager.LayoutParams fullOverlayParams(){
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.START; return lp;
    }

    private void scheduleIdle(){
        cancelIdle();
        int sec=Math.max(1,prefs==null?5:prefs.getInt("idle_seconds",5));
        handler.postDelayed(idleRunnable,sec*1000L);
    }
    private void cancelIdle(){ if(handler!=null)handler.removeCallbacks(idleRunnable); }

    private void dockBubble(){
        if(!bubbleAdded||bubble==null||bubbleLp==null||bubble.getVisibility()!=View.VISIBLE)return;
        String mode=prefs.getString("hide_mode","half");
        if("none".equals(mode)){bubble.setAlpha(1f);snapBubble(false);return;}
        snapBubble("half".equals(mode));
        bubble.setAlpha(prefs.getFloat("idle_alpha",.45f)); docked=true;
    }
    private void makeBubbleVisible(){
        if(!bubbleAdded||bubble==null)return;
        bubble.setAlpha(1f);
        if(docked){snapBubble(false);docked=false;}
    }
    private void snapBubble(boolean halfHidden){
        if(!bubbleAdded||bubbleLp==null)return;
        String edge=prefs.getString("edge_mode","auto");
        boolean left;
        if("left".equals(edge))left=true; else if("right".equals(edge))left=false; else left=bubbleLp.x+dp(BUBBLE_DP)/2<screenWidth()/2;
        int size=dp(BUBBLE_DP);
        if(left) bubbleLp.x=halfHidden?-size/2:dp(4); else bubbleLp.x=halfHidden?screenWidth()-size/2:screenWidth()-size-dp(4);
        safeUpdate(bubble,bubbleLp);
    }

    private void safeUpdate(View v, WindowManager.LayoutParams lp){ try{wm.updateViewLayout(v,lp);}catch(Exception ignored){} }
    private int screenWidth(){ android.util.DisplayMetrics m=new android.util.DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(m);return m.widthPixels; }
    private int screenHeight(){ android.util.DisplayMetrics m=new android.util.DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(m);return m.heightPixels; }
    private int dp(float v){ return Math.round(v*getResources().getDisplayMetrics().density); }

    private String resolveAppName(String pkg){
        if(pkg==null||pkg.isEmpty())return "未知应用";
        try{ApplicationInfo ai=getPackageManager().getApplicationInfo(pkg,0);CharSequence label=getPackageManager().getApplicationLabel(ai);return label==null?pkg:label.toString();}
        catch(PackageManager.NameNotFoundException e){return pkg;}
    }
    private String modeName(String mode){if("FULL".equals(mode))return "全屏取词";if("CUSTOM".equals(mode))return "自定义取词";if("RECT".equals(mode))return "矩形取词";return "取词";}
    private String shorten(String s,int max){if(s==null)return "";s=s.replace('\n',' ');return s.length()<=max?s:s.substring(0,max)+"…";}
    private void copyToClipboard(String s){ ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("屏幕取词",s));toast("已复制到剪贴板"); }
    private void toast(String s){ handler.post(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show()); }
}
