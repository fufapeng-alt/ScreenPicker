package com.pengyi.screenpicker;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {
    private static final int PRIMARY = Color.rgb(91,108,255);
    private static final int BG = Color.rgb(245,247,251);
    private static final int TEXT = Color.rgb(21,24,39);
    private static final int SUB = Color.rgb(110,115,134);

    private FrameLayout pageHost;
    private AppDb db;
    private final String[] navNames = {"历史", "日志", "设置", "权限"};
    private int currentPage = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new AppDb(this);
        setContentView(buildRoot());
        showPage(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ScreenAccessibilityService service = ScreenAccessibilityService.getInstance();
        if (service != null) service.refreshFloatingUi();
        showPage(currentPage);
    }

    private View buildRoot() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(18), dp(20), dp(10));
        TextView title = text("屏幕取词", 24, TEXT, true);
        TextView sub = text("全局提取屏幕文字 · 悬浮窗快速取词", 13, SUB, false);
        header.addView(title);
        header.addView(sub, lpMatchWrap(0, dp(3),0,0));
        root.addView(header);

        pageHost = new FrameLayout(this);
        root.addView(pageHost, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(8), dp(7), dp(8), dp(9));
        nav.setBackgroundColor(Color.WHITE);
        for (int i=0;i<navNames.length;i++) {
            final int index=i;
            Button b = new Button(this);
            b.setText(navNames[i]);
            b.setTextSize(13);
            b.setAllCaps(false);
            b.setOnClickListener(v -> showPage(index));
            nav.addView(b, new LinearLayout.LayoutParams(0, dp(50), 1));
        }
        root.addView(nav);
        return root;
    }

    private void showPage(int index) {
        currentPage = index;
        if (pageHost == null) return;
        pageHost.removeAllViews();
        View page;
        switch (index) {
            case 1: page = buildLogs(); break;
            case 2: page = buildSettings(); break;
            case 3: page = buildPermissions(); break;
            default: page = buildHistory(); break;
        }
        pageHost.addView(page);
    }

    private View buildHistory() {
        ScrollView scroll = scroll();
        LinearLayout box = column();
        box.setPadding(dp(16), dp(8), dp(16), dp(20));

        LinearLayout status = card();
        boolean overlay = Settings.canDrawOverlays(this);
        boolean acc = isAccessibilityEnabled();
        TextView state = text(acc && overlay ? "悬浮取词已就绪" : "需要完成权限设置", 18, TEXT, true);
        TextView desc = text(acc && overlay ? "点击屏幕边缘的悬浮球即可开始取词。" : "开启悬浮窗和无障碍服务后，悬浮球才会显示。", 13, SUB, false);
        status.addView(state);
        status.addView(desc, lpMatchWrap(0,dp(4),0,0));
        Button go = actionButton(acc && overlay ? "刷新悬浮球" : "去设置权限");
        go.setOnClickListener(v -> {
            if (acc && overlay) {
                ScreenAccessibilityService s = ScreenAccessibilityService.getInstance();
                if (s != null) { s.refreshFloatingUi(); toast("已刷新悬浮球"); }
                else toast("无障碍服务尚未连接");
            } else showPage(3);
        });
        status.addView(go, lpMatchWrap(0,dp(12),0,0));
        box.addView(status);

        TextView recent = text("最近取词", 17, TEXT, true);
        box.addView(recent, lpMatchWrap(0,dp(18),0,dp(8)));
        List<AppDb.HistoryRow> rows = db.recentHistory(50);
        if (rows.isEmpty()) {
            LinearLayout empty = card();
            empty.addView(text("还没有取词记录", 16, TEXT, true));
            empty.addView(text("完成一次全屏、自定义或矩形取词后，记录会出现在这里。", 13, SUB, false), lpMatchWrap(0,dp(4),0,0));
            box.addView(empty);
        } else {
            for (AppDb.HistoryRow r : rows) box.addView(historyCard(r), lpMatchWrap(0,0,0,dp(10)));
        }
        scroll.addView(box);
        return scroll;
    }

    private View historyCard(AppDb.HistoryRow r) {
        LinearLayout c = card();
        TextView app = text((r.appName == null || r.appName.isEmpty() ? r.packageName : r.appName) + "  ·  " + modeName(r.mode), 14, TEXT, true);
        TextView time = text(AppDb.time(r.createdAt), 12, SUB, false);
        TextView body = text(ellipsis(r.text, 240), 14, TEXT, false);
        body.setTextIsSelectable(true);
        c.addView(app);
        c.addView(time, lpMatchWrap(0,dp(3),0,dp(9)));
        c.addView(body);
        Button copy = smallButton("复制");
        copy.setOnClickListener(v -> copy(r.text));
        c.addView(copy, lpWrapWrap(Gravity.END,0,dp(8),0,0));
        return c;
    }

    private View buildLogs() {
        ScrollView scroll = scroll();
        LinearLayout box = column(); box.setPadding(dp(16),dp(8),dp(16),dp(20));
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text("操作日志",17,TEXT,true); header.addView(t,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        Button clear = smallButton("清空");
        clear.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("清空日志？").setMessage("此操作无法撤销。").setNegativeButton("取消",null).setPositiveButton("清空",(d,w)->{db.clearLogs();showPage(1);}).show());
        header.addView(clear); box.addView(header, lpMatchWrap(0,0,0,dp(8)));
        List<AppDb.LogRow> rows = db.recentLogs(100);
        if(rows.isEmpty()) box.addView(cardText("暂无日志", "悬浮服务连接、取词、OCR、复制和异常信息会记录在这里。"));
        for(AppDb.LogRow r: rows){
            LinearLayout c=card();
            c.addView(text(AppDb.time(r.createdAt)+"  ["+r.level+"]",12,SUB,false));
            c.addView(text(r.message,14,TEXT,false),lpMatchWrap(0,dp(5),0,0));
            box.addView(c,lpMatchWrap(0,0,0,dp(8)));
        }
        scroll.addView(box); return scroll;
    }

    private View buildSettings() {
        ScrollView scroll=scroll(); LinearLayout box=column(); box.setPadding(dp(16),dp(8),dp(16),dp(24));
        android.content.SharedPreferences p=getSharedPreferences("settings",MODE_PRIVATE);
        box.addView(sectionTitle("悬浮窗"));
        box.addView(settingRow("屏幕吸附", edgeLabel(p.getString("edge_mode","auto")), v -> chooseEdge()));
        box.addView(settingRow("无操作后隐藏", p.getInt("idle_seconds",5)+" 秒", v -> chooseIdle()));
        box.addView(settingRow("隐藏方式", hideLabel(p.getString("hide_mode","half")), v -> chooseHideMode()));
        box.addView(settingRow("隐藏透明度", Math.round(p.getFloat("idle_alpha",0.45f)*100)+"%", v -> chooseAlpha()));

        box.addView(sectionTitle("取词"), lpMatchWrap(0,dp(14),0,0));
        box.addView(readOnlyRow("文字识别", "Accessibility 优先，OCR 兜底"));
        box.addView(readOnlyRow("OCR 模型", "ML Kit 中文模型（兼容拉丁字符）"));
        box.addView(readOnlyRow("截图方式", "Android Accessibility Screenshot"));

        box.addView(sectionTitle("数据"), lpMatchWrap(0,dp(14),0,0));
        Button clearHistory=actionButton("清空全部取词历史");
        clearHistory.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("清空取词历史？").setNegativeButton("取消",null).setPositiveButton("清空",(d,w)->{db.clearHistory();toast("历史记录已清空");}).show());
        box.addView(clearHistory);
        TextView tip=text("设置变更会在悬浮球下一次显示时生效。",12,SUB,false); box.addView(tip,lpMatchWrap(0,dp(12),0,0));
        scroll.addView(box); return scroll;
    }

    private View buildPermissions() {
        ScrollView scroll=scroll(); LinearLayout box=column(); box.setPadding(dp(16),dp(8),dp(16),dp(24));
        boolean overlay=Settings.canDrawOverlays(this), acc=isAccessibilityEnabled();
        int done=(overlay?1:0)+(acc?1:0);
        LinearLayout top=card(); top.addView(text("权限完成度  "+done+" / 2",19,TEXT,true));
        top.addView(text(done==2?"核心权限已完成，可以使用悬浮取词。":"还差 "+(2-done)+" 项核心权限。",13,done==2?Color.rgb(46,156,106):SUB,false),lpMatchWrap(0,dp(5),0,0));
        box.addView(top);
        box.addView(permissionCard("悬浮窗权限", overlay, "让取词球和识别结果显示在其他应用上层。", v->openOverlayPermission()), lpMatchWrap(0,dp(12),0,0));
        box.addView(permissionCard("无障碍服务", acc, "主动取词时读取界面文字，并在需要时调用系统截图进行 OCR。", v->openAccessibility()), lpMatchWrap(0,dp(10),0,0));
        LinearLayout privacy=card();
        privacy.addView(text("数据说明",16,TEXT,true));
        privacy.addView(text("当前版本的 OCR 在设备本机运行。取词结果只保存到本机数据库，不会由本 APP 主动上传到服务器。受系统安全策略保护的窗口可能无法截图。",13,SUB,false),lpMatchWrap(0,dp(6),0,0));
        box.addView(privacy,lpMatchWrap(0,dp(12),0,0));
        scroll.addView(box); return scroll;
    }

    private View permissionCard(String title, boolean ok, String desc, View.OnClickListener click) {
        LinearLayout c=card();
        LinearLayout line=new LinearLayout(this); line.setGravity(Gravity.CENTER_VERTICAL);
        line.addView(text(title,16,TEXT,true),new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        TextView state=text(ok?"已开启":"未开启",13,ok?Color.rgb(46,156,106):Color.rgb(194,75,63),true); line.addView(state); c.addView(line);
        c.addView(text(desc,13,SUB,false),lpMatchWrap(0,dp(6),0,dp(10)));
        Button b=actionButton(ok?"重新检查":"去开启"); b.setOnClickListener(click); c.addView(b); return c;
    }

    private View settingRow(String name, String value, View.OnClickListener click) {
        LinearLayout row=card(); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setOnClickListener(click);
        LinearLayout txt=column(); txt.addView(text(name,15,TEXT,true)); txt.addView(text(value,13,SUB,false),lpMatchWrap(0,dp(3),0,0));
        row.addView(txt,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        TextView arrow=text("›",26,SUB,false); row.addView(arrow); return row;
    }

    private View readOnlyRow(String name,String value){ LinearLayout c=card(); c.addView(text(name,15,TEXT,true)); c.addView(text(value,13,SUB,false),lpMatchWrap(0,dp(4),0,0)); return c; }

    private void chooseEdge(){
        String[] items={"自动吸附最近边缘","固定左侧","固定右侧"}; String[] vals={"auto","left","right"};
        new AlertDialog.Builder(this).setTitle("屏幕吸附").setItems(items,(d,w)->{getSharedPreferences("settings",MODE_PRIVATE).edit().putString("edge_mode",vals[w]).apply();refreshService();showPage(2);}).show();
    }
    private void chooseIdle(){
        String[] items={"3 秒","5 秒","8 秒","10 秒","15 秒"}; int[] vals={3,5,8,10,15};
        new AlertDialog.Builder(this).setTitle("无操作后隐藏").setItems(items,(d,w)->{getSharedPreferences("settings",MODE_PRIVATE).edit().putInt("idle_seconds",vals[w]).apply();refreshService();showPage(2);}).show();
    }
    private void chooseHideMode(){
        String[] items={"半隐藏到屏幕外","仅降低透明度","不隐藏"}; String[] vals={"half","alpha","none"};
        new AlertDialog.Builder(this).setTitle("隐藏方式").setItems(items,(d,w)->{getSharedPreferences("settings",MODE_PRIVATE).edit().putString("hide_mode",vals[w]).apply();refreshService();showPage(2);}).show();
    }
    private void chooseAlpha(){
        String[] items={"30%","40%","45%","55%","70%"}; float[] vals={.30f,.40f,.45f,.55f,.70f};
        new AlertDialog.Builder(this).setTitle("隐藏透明度").setItems(items,(d,w)->{getSharedPreferences("settings",MODE_PRIVATE).edit().putFloat("idle_alpha",vals[w]).apply();refreshService();showPage(2);}).show();
    }

    private void refreshService(){ ScreenAccessibilityService s=ScreenAccessibilityService.getInstance(); if(s!=null)s.refreshFloatingUi(); }

    private void openOverlayPermission(){
        try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); }
        catch(Exception e){ startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)); }
    }
    private void openAccessibility(){ startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }

    private boolean isAccessibilityEnabled(){
        AccessibilityManager am=(AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);
        if(am==null)return false;
        List<AccessibilityServiceInfo> list=am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        ComponentName wanted=new ComponentName(this,ScreenAccessibilityService.class);
        for(AccessibilityServiceInfo info:list){
            if(info.getResolveInfo()!=null && info.getResolveInfo().serviceInfo!=null){
                ComponentName c=new ComponentName(info.getResolveInfo().serviceInfo.packageName,info.getResolveInfo().serviceInfo.name);
                if(c.equals(wanted)) return true;
            }
        }
        return false;
    }

    private LinearLayout card(){
        LinearLayout v=column(); v.setPadding(dp(16),dp(14),dp(16),dp(14));
        android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(Color.WHITE); g.setCornerRadius(dp(18)); g.setStroke(dp(1),Color.rgb(231,234,243)); v.setBackground(g); return v;
    }
    private View cardText(String title,String body){ LinearLayout c=card();c.addView(text(title,16,TEXT,true));c.addView(text(body,13,SUB,false),lpMatchWrap(0,dp(4),0,0));return c; }
    private TextView sectionTitle(String s){ return text(s,17,TEXT,true); }
    private LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private ScrollView scroll(){ ScrollView s=new ScrollView(this); s.setFillViewport(true); s.setBackgroundColor(BG); return s; }
    private TextView text(String s,float size,int color,boolean bold){ TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setLineSpacing(0,1.12f);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t; }
    private Button actionButton(String s){ Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(Color.WHITE);b.setAllCaps(false);android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(PRIMARY);g.setCornerRadius(dp(14));b.setBackground(g);b.setPadding(dp(14),0,dp(14),0);b.setMinHeight(dp(44));return b; }
    private Button smallButton(String s){ Button b=actionButton(s);b.setMinHeight(dp(38));b.setTextSize(13);return b; }
    private int dp(float v){ return Math.round(v*getResources().getDisplayMetrics().density); }
    private LinearLayout.LayoutParams lpMatchWrap(int l,int t,int r,int b){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(l,t,r,b);return p; }
    private LinearLayout.LayoutParams lpWrapWrap(int gravity,int l,int t,int r,int b){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.gravity=gravity;p.setMargins(l,t,r,b);return p; }
    private String ellipsis(String s,int n){ if(s==null)return "";return s.length()<=n?s:s.substring(0,n)+"…"; }
    private String modeName(String mode){ if("FULL".equals(mode))return "全屏取词";if("CUSTOM".equals(mode))return "自定义取词";if("RECT".equals(mode))return "矩形取词";return mode==null?"取词":mode; }
    private String edgeLabel(String v){ if("left".equals(v))return "固定左侧";if("right".equals(v))return "固定右侧";return "自动吸附最近边缘"; }
    private String hideLabel(String v){ if("alpha".equals(v))return "仅降低透明度";if("none".equals(v))return "不隐藏";return "半隐藏到屏幕外"; }
    private void copy(String s){ ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("屏幕取词",s));toast("已复制"); }
    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
