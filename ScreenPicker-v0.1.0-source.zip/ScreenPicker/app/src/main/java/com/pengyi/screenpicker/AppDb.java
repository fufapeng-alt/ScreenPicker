package com.pengyi.screenpicker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AppDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "screen_picker.db";
    private static final int DB_VERSION = 1;

    public AppDb(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE history (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, package_name TEXT, app_name TEXT, mode TEXT, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT, level TEXT, message TEXT NOT NULL, created_at INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    public void addHistory(String text, String pkg, String appName, String mode) {
        if (text == null || text.trim().isEmpty()) return;
        ContentValues v = new ContentValues();
        v.put("text", text.trim());
        v.put("package_name", pkg);
        v.put("app_name", appName);
        v.put("mode", mode);
        v.put("created_at", System.currentTimeMillis());
        getWritableDatabase().insert("history", null, v);
        getWritableDatabase().execSQL("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY id DESC LIMIT 1000)");
    }

    public void log(String level, String message) {
        ContentValues v = new ContentValues();
        v.put("level", level);
        v.put("message", message);
        v.put("created_at", System.currentTimeMillis());
        getWritableDatabase().insert("logs", null, v);
        getWritableDatabase().execSQL("DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY id DESC LIMIT 500)");
    }

    public List<HistoryRow> recentHistory(int limit) {
        List<HistoryRow> rows = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,text,package_name,app_name,mode,created_at FROM history ORDER BY id DESC LIMIT ?",
                new String[]{String.valueOf(limit)})) {
            while (c.moveToNext()) {
                rows.add(new HistoryRow(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getLong(5)));
            }
        }
        return rows;
    }

    public List<LogRow> recentLogs(int limit) {
        List<LogRow> rows = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,level,message,created_at FROM logs ORDER BY id DESC LIMIT ?",
                new String[]{String.valueOf(limit)})) {
            while (c.moveToNext()) rows.add(new LogRow(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3)));
        }
        return rows;
    }

    public void clearHistory() { getWritableDatabase().delete("history", null, null); }
    public void clearLogs() { getWritableDatabase().delete("logs", null, null); }

    public static String time(long value) {
        return new SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()).format(new Date(value));
    }

    public static class HistoryRow {
        public final long id, createdAt;
        public final String text, packageName, appName, mode;
        public HistoryRow(long id, String text, String packageName, String appName, String mode, long createdAt) {
            this.id = id; this.text = text; this.packageName = packageName; this.appName = appName; this.mode = mode; this.createdAt = createdAt;
        }
    }

    public static class LogRow {
        public final long id, createdAt;
        public final String level, message;
        public LogRow(long id, String level, String message, long createdAt) {
            this.id = id; this.level = level; this.message = message; this.createdAt = createdAt;
        }
    }
}
