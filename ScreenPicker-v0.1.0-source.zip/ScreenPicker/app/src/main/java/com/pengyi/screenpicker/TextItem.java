package com.pengyi.screenpicker;

import android.graphics.Rect;

public class TextItem {
    public final String text;
    public final Rect bounds;
    public boolean selected;

    public TextItem(String text, Rect bounds) {
        this.text = text == null ? "" : text.trim();
        this.bounds = new Rect(bounds);
    }
}
