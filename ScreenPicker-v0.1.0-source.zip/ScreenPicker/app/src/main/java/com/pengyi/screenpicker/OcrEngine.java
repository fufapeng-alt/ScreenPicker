package com.pengyi.screenpicker;

import android.graphics.Bitmap;
import android.graphics.Rect;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class OcrEngine {
    public interface Callback {
        void onSuccess(List<TextItem> items, String fullText);
        void onError(Exception error);
    }

    private final TextRecognizer chineseRecognizer;
    private final TextRecognizer latinRecognizer;

    public OcrEngine() {
        chineseRecognizer = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        latinRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    public void recognize(Bitmap bitmap, Rect filter, Callback callback) {
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        Task<Text> chineseTask = chineseRecognizer.process(image);
        chineseTask.addOnCompleteListener(chineseDone -> {
            Task<Text> latinTask = latinRecognizer.process(image);
            latinTask.addOnCompleteListener(latinDone -> {
                if (!chineseDone.isSuccessful() && !latinDone.isSuccessful()) {
                    Exception error = latinDone.getException() != null ? latinDone.getException() : chineseDone.getException();
                    callback.onError(error == null ? new RuntimeException("OCR failed") : error);
                    return;
                }

                List<TextItem> items = new ArrayList<>();
                if (chineseDone.isSuccessful() && chineseDone.getResult() != null) {
                    append(items, chineseDone.getResult(), filter);
                }
                if (latinDone.isSuccessful() && latinDone.getResult() != null) {
                    append(items, latinDone.getResult(), filter);
                }

                items.sort(Comparator.comparingInt((TextItem i) -> i.bounds.top)
                        .thenComparingInt(i -> i.bounds.left));
                callback.onSuccess(items, join(items));
            });
        });
    }

    private static void append(List<TextItem> out, Text result, Rect filter) {
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                for (Text.Element element : line.getElements()) {
                    Rect b = element.getBoundingBox();
                    String value = element.getText() == null ? "" : element.getText().trim();
                    if (b == null || value.isEmpty()) continue;
                    if (filter != null && !filter.contains(b.centerX(), b.centerY())) continue;
                    TextItem candidate = new TextItem(value, b);
                    if (!isDuplicate(out, candidate)) out.add(candidate);
                }
            }
        }
    }

    private static boolean isDuplicate(List<TextItem> existing, TextItem candidate) {
        for (TextItem item : existing) {
            if (item.text.equalsIgnoreCase(candidate.text) && overlapRatio(item.bounds, candidate.bounds) > 0.45f) return true;
            if (overlapRatio(item.bounds, candidate.bounds) > 0.78f) return true;
        }
        return false;
    }

    private static float overlapRatio(Rect a, Rect b) {
        int left = Math.max(a.left, b.left);
        int top = Math.max(a.top, b.top);
        int right = Math.min(a.right, b.right);
        int bottom = Math.min(a.bottom, b.bottom);
        int w = Math.max(0, right - left);
        int h = Math.max(0, bottom - top);
        float intersection = (float) w * h;
        float smaller = Math.min((float) Math.max(1, a.width() * a.height()),
                (float) Math.max(1, b.width() * b.height()));
        return intersection / smaller;
    }

    public void close() {
        chineseRecognizer.close();
        latinRecognizer.close();
    }

    public static String join(List<TextItem> items) {
        if (items == null || items.isEmpty()) return "";
        StringBuilder out = new StringBuilder();
        int lastTop = Integer.MIN_VALUE;
        int threshold = 32;
        for (TextItem item : items) {
            if (out.length() > 0) {
                if (lastTop != Integer.MIN_VALUE && Math.abs(item.bounds.top - lastTop) > threshold) out.append('\n');
                else out.append(' ');
            }
            out.append(item.text);
            lastTop = item.bounds.top;
        }
        return out.toString().trim();
    }
}
