package com.pengyi.screenpicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;

public class RectSelectionView extends View {
    public interface Listener { void onSelected(Rect rect); void onCancelled(); }

    private final Paint dim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint area = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Listener listener;
    private float sx, sy, ex, ey;
    private boolean dragging;

    public RectSelectionView(Context context, Listener listener) {
        super(context);
        this.listener = listener;
        dim.setColor(Color.argb(92, 0, 0, 0));
        area.setColor(Color.argb(28, 255, 255, 255));
        border.setColor(Color.rgb(91, 108, 255));
        border.setStrokeWidth(dp(3));
        border.setStyle(Paint.Style.STROKE);
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    @Override protected void onDraw(Canvas canvas) {
        canvas.drawRect(0, 0, getWidth(), getHeight(), dim);
        if (dragging || Math.abs(ex - sx) > 1) {
            Rect r = rect();
            canvas.drawRect(r, area);
            canvas.drawRoundRect(r.left, r.top, r.right, r.bottom, dp(8), dp(8), border);
        }
    }

    private Rect rect() {
        int l = (int) Math.min(sx, ex), t = (int) Math.min(sy, ey), r = (int) Math.max(sx, ex), b = (int) Math.max(sy, ey);
        return new Rect(l, t, r, b);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                sx = ex = e.getX(); sy = ey = e.getY(); dragging = true; invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                ex = e.getX(); ey = e.getY(); invalidate(); return true;
            case MotionEvent.ACTION_UP:
                ex = e.getX(); ey = e.getY(); dragging = false; invalidate();
                Rect r = rect();
                if (r.width() >= dp(45) && r.height() >= dp(30)) listener.onSelected(r);
                else listener.onCancelled();
                return true;
        }
        return true;
    }
}
