# 屏幕取词 ScreenPicker

Android 11+ 的全局屏幕取词 MVP，核心代码以 Java 编写。

## 当前功能

- 悬浮球显示、拖动、左右/自动吸附
- 默认 5 秒无操作后收起菜单、吸附边缘、半隐藏与半透明
- 全屏取词
- 自定义点选取词
- 矩形框取词
- AccessibilityNodeInfo 优先直接获取标准 Android UI 文本
- 无可访问文本时，使用 AccessibilityService `takeScreenshot()` + ML Kit 中文 OCR
- 当前屏幕绘制文字识别框
- 自定义模式可点选文本、全选、复制
- 结果复制到剪贴板
- 取词历史：文本、来源 APP、包名、取词模式、时间
- 操作日志
- 设置页：吸附位置、无操作隐藏时间、隐藏方式、透明度
- 权限页：悬浮窗权限、无障碍权限、完成度检测

## 环境

- Java 17
- minSdk 30（Android 11）
- targetSdk 35
- compileSdk 35
- Android Gradle Plugin 8.7.3
- ML Kit Chinese Text Recognition 16.0.1

## 本地构建

用 Android Studio 打开根目录，等待 Gradle 同步后执行：

```bash
gradle :app:assembleDebug
```

输出：

```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub 自动构建

工程已包含：

```text
.github/workflows/build-apk.yml
```

推送到 GitHub 后会自动构建 Debug APK，并上传为 `ScreenPicker-debug-apk` Actions Artifact。

## 首次使用

1. 打开 APP -> 权限。
2. 开启“悬浮窗权限”。
3. 开启“屏幕取词”无障碍服务。
4. 返回 APP，悬浮球会自动显示。
5. 点击悬浮球选择取词模式。

## 限制

- 设置了 `FLAG_SECURE` 的窗口会被 Android 系统禁止截图。
- 某些自绘界面、游戏、视频内容只能走 OCR。
- 厂商 ROM 可能需要额外允许后台运行/悬浮窗。
